let user = {
    user1: {
        id: 1,
        name: "Majid",
        money: "200$"
    },
    user2: {
        id: 2,
        name: "Nurullo",
        money: "100e"
    },
    user3: {
        id: 3,
        name: "Ali",
        money: "1500r"
    },
    user4: {
        id: 4,
        name: "Belek",
        money: "1000s"
    },
    user5: {
        id: 5,
        name: "Aziz",
        money: "250$"
    },
    user6: {
        id: 6,
        name: "Alex",
        money: "150e"
    },
    user7: {
        id: 7,
        name: "Maanai",
        money: "1550r"
    },
    user8: {
        id: 8,
        name: "Muslima",
        money: "1000s"
    },
    user9: {
        id: 9,
        name: "Banu",
        money: "800s"
    },
    user10: {
        id: 10,
        name: "Danu",
        money: "700s"
    },
}

// function getobj(letter){
// for ( i in user){
//     letter = letter.toUpperCase()
//     let k = user[i]["name"].toUpperCase()
//   if(k.startsWith(letter)){
//     console.log(user[i]); 
//   }
  
// }
// }
// getobj("i")




// function getobj(letter){
// for ( i in user){
//   if(user[i]["money"].includes(letter)){
//     console.log(user[i]); 
//   }
// }
// }
// getobj("1000s")
 